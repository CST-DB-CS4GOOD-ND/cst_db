<?php
$db = mysqli_connect("localhost", "root", "legendary", "login") or die ("Failed to connect");

?>