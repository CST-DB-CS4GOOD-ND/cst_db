# php-mysql-login
- A basic PHP and MySQL login and registration system.

# Instrunctions to run
- Create a MySQL database named login(or anything else and change the fourth parameter in <code>mysqli_connect()</code> in <code>connection.php</code>)
- Create a table named members( or anything else and change the ninth line in <code>index.php</code> to alter <code>$sql</code>
- Add users to the table and activate connection (or use the register page to register new users).
- Edit the <code>user.php</code> to alter the post login screen for user.
